#!/bin/bash

# Use Unix commands to print the name of each character with dialogue in the script, one name per line. 
echo "Question 1.5"
# TODO: Replace the following line with your code.
echo "Not Implemented"

# First, extract all lines of dialogue in this script. 
# Then, normalize and tokenize this text such that all alphabetic characters are converted to lowercase and words are sequences of alphabetic characers. 
# Finally, print the top-20 most frequent word types and their corresponding counts.
# Hint: Ignore parantheticals. These contain short stage directions.
echo
echo "Question 1.6"
# TODO: Replace the following line with your code.
echo "Not Implemented"